﻿namespace API.DataTransferObjects
{
	public class TaskPriorityDto
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public string Order { get; set; }
	}
}