﻿namespace API.DataTransferObjects
{
	public class TeamDto
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public string TeamLead { get; set; }
	}
}