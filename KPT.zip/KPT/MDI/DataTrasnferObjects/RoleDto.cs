﻿namespace Client.DataTransferObjects
{
	public class RoleDto
	{
		public int Id { get; set; }
		public string FriendlyName { get; set; }
		public string SysRole { get; set; }
	}
}