﻿namespace Client.DataTransferObjects
{
	public class ProjectStatusDto
	{
		public int Id { get; set; }
		public string Name { get; set; }
	}
}